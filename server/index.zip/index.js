const express = require ("express");
const app = express();
const mysql = require ("mysql2");
const cors = require ("cors");

app.use(cors());
app.use (express.json());
const db = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "123123",
    database: "infoCadastro",
    port:3307
    
})

app.post ("/cad", (req,res) =>{
    const {cad} = req.body;
    let SQL = "INSERT INTO cadastro ( nome, cpf, email, senha ) VALUES (?)";

    db.query(SQL,cad, (err,result) => {
        console.log(err);
    })
})

app.listen(3001, () => {
    console.log("rodando servidor")
})